[![Typing SVG](http://readme-typing-svg.herokuapp.com?color=3CFF00&size=30&width=700&lines=INSTALLING+SQLITE+ON+WINDOWS)](https://git.io/typing-svg)

Step 1 − Go to SQLite download page: https://www.sqlite.org/download.html and download precompiled binaries from Windows section.

Step 2 − Download sqlite-shell-win32-*.zip and sqlite-dll-win32-*.zip zipped files.

Step 3 − Create a folder C:\>sqlite and unzip above two zipped files in this folder, which will give you sqlite3.def, sqlite3.dll and sqlite3.exe files.

Step 4 − Add C:\>sqlite in your PATH environment variable and finally go to the command prompt and issue sqlite3 command, which should display the following result.

	
	C:\>sqlite3
	SQLite version 3.7.15.2 2013-01-09 11:53:05
	Enter ".help" for instructions
	Enter SQL statements terminated with a ";"
	sqlite>

[![Typing SVG](http://readme-typing-svg.herokuapp.com?color=3CFF00&size=30&width=700&lines=INSTALLING+SQLITE+ON+LINUX)](https://git.io/typing-svg)

Today, almost all the flavours of Linux OS are being shipped with SQLite. So you just issue the following command to check if you already have SQLite installed on your machine.

	$sqlite3
	SQLite version 3.7.15.2 2013-01-09 11:53:05
	Enter ".help" for instructions
	Enter SQL statements terminated with a ";"
	sqlite>
	
If you do not see the above result, then it means you do not have SQLite installed on your Linux machine. Following are the following steps to install SQLite −

Step 1 − Open your Terminal Emulator.

Step 2 − Run the following command −
	
	$sudo apt update && sudo apt install sqlite3

	
[![Typing SVG](http://readme-typing-svg.herokuapp.com?color=3CFF00&size=30&width=700&lines=INSTALLING+SQLITE+ON+LINUX+FROM+SOURCE)](https://git.io/typing-svg)
	
Today, almost all the flavours of Linux OS are being shipped with SQLite. So you just issue the following command to check if you already have SQLite installed on your machine.

	$sqlite3
	SQLite version 3.7.15.2 2013-01-09 11:53:05
	Enter ".help" for instructions
	Enter SQL statements terminated with a ";"
	sqlite>
	
If you do not see the above result, then it means you do not have SQLite installed on your Linux machine. Following are the following steps to install SQLite −

Step 1 − Go to SQLite download page: https://www.sqlite.org/download.html and download sqlite-autoconf-*.tar.gz from source code section.

Step 2 − Run the following command −

	$tar xvfz sqlite-autoconf-3071502.tar.gz
	$cd sqlite-autoconf-3071502
	$./configure --prefix=/usr/local
	$make
	$make install
	
The above command will end with SQLite installation on your Linux machine. Which you can verify as explained above.


[![Typing SVG](http://readme-typing-svg.herokuapp.com?color=3CFF00&size=30&width=700&lines=INSTALLING+SQLITE+ON+MAC+OS)](https://git.io/typing-svg)

Though the latest version of Mac OS X comes pre-installed with SQLite but if you do not have installation available then just follow these following steps −

Step 1 − Go to SQLite download page: https://www.sqlite.org/download.html and download sqlite-autoconf-*.tar.gz from source code section.

Step 2 − Run the following command −

	$tar xvfz sqlite-autoconf-3071502.tar.gz
	$cd sqlite-autoconf-3071502
	$./configure --prefix=/usr/local
	$make
	$make install

The above procedure will end with SQLite installation on your Mac OS X machine. Which you can verify by issuing the following command −

	$sqlite3
	SQLite version 3.7.15.2 2013-01-09 11:53:05
	Enter ".help" for instructions
	Enter SQL statements terminated with a ";"
	sqlite>

Finally, you have SQLite command prompt where you can issue SQLite commands for your exercises.
