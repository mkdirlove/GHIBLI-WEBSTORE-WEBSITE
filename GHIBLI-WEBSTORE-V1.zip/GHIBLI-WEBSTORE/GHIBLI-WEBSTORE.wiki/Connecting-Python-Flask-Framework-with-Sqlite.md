[![Typing SVG](http://readme-typing-svg.herokuapp.com?color=3CFF00&size=30&width=900&lines=CONNECTING+PYTHON+FLASK+FRAMEWORK+WITH+SQLITE)](https://git.io/typing-svg)

Step 1 − Install sqlitebrowser in your machine using the following commands (In my case: I'm using Linux machine cause it's pre-installed).
	
	$sudo apt update
    $sudo apt install sqlitebrowser

Step 2 − Open your sqlitebrowser and create a new database file.
     
<img src="https://raw.githubusercontent.com/mkdirlove/GHIBLI-WEBSTORE/main/wiki-img/create-db.png">

Step 3 − Create table.

<img src="https://raw.githubusercontent.com/mkdirlove/GHIBLI-WEBSTORE/main/wiki-img/create-tb.png">

Step 4 − Create columns.

<img src="https://raw.githubusercontent.com/mkdirlove/GHIBLI-WEBSTORE/main/wiki-img/create-cln.png">

Step 5 − Edit columns.

<img src="https://raw.githubusercontent.com/mkdirlove/GHIBLI-WEBSTORE/main/wiki-img/edit-cln.png">

Step 6 − Save database.

<img src="https://raw.githubusercontent.com/mkdirlove/GHIBLI-WEBSTORE/main/wiki-img/save-db.png">

Step 7 − Connecting Python Flask Framework to your database.

You can connect it using the following lines of code.

        from cs50 import SQL
        from flask_session import Session
        from flask import Flask, render_template, redirect, request, session, jsonify
        from datetime import datetime

        # # Instantiate Flask object named app
        app = Flask(__name__)

        # # Configure sessions
        app.config["SESSION_PERMANENT"] = False
        app.config["SESSION_TYPE"] = "filesystem"
        Session(app)

        # Creates a connection to the database
        db = SQL ( "sqlite:///data.db" )


Step 8 − Creating a routing function.

I used the checkout function on the code as an example.


        @app.route("/checkout/")
        def checkout():
            order = db.execute("SELECT * from cart")
            # Update purchase history of current customer
            for item in order:
                db.execute("INSERT INTO purchases (uid, id, samplename, image, quantity) VALUES(:uid, :id, :samplename, :image, :quantity)", uid=session["uid"], id=item["id"], samplename=item["samplename"], image=item["image"], quantity=item["qty"] )
            # Clear shopping cart
            db.execute("DELETE from cart")
            shoppingCart = []
            shopLen = len(shoppingCart)
            totItems, total, display = 0, 0, 0
            # Redirect to home page
            return redirect('/')

That's all and now you have been created your own database file and routing function that is connected to your database.